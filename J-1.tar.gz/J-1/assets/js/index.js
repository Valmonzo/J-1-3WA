function monBonjour() {
    document.getElementById('bonjour').innerHTML = 'Bonjour'
}